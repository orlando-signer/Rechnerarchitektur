#include <stdlib.h>
#include <stdio.h>
#include "mips.h"

int main (int argc, const char * argv[]) {
	initialize();
	run();
	return 0;
}
